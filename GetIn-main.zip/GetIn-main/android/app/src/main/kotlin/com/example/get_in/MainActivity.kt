package com.example.get_in

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
